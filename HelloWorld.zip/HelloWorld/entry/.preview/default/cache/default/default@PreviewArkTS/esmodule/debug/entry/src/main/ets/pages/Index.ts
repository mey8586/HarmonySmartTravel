if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WebHeightPage_Params {
    webviewController?: WebviewController;
    scroller?: Scroller;
}
import webview from "@ohos:web.webview";
class WebHeightPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.webviewController = new webview.WebviewController();
        this.scroller = new Scroller();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WebHeightPage_Params) {
        if (params.webviewController !== undefined) {
            this.webviewController = params.webviewController;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
    }
    updateStateVars(params: WebHeightPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private webviewController: WebviewController;
    private scroller: Scroller;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Navigation.create(new NavPathStack(), { moduleName: "entry", pagePath: "entry/src/main/ets/pages/Index", isUserCreateStack: false });
            Navigation.debugLine("entry/src/main/ets/pages/Index.ets(13:5)", "entry");
            Navigation.title("标题栏");
        }, Navigation);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(14:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create(this.scroller);
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(15:9)", "entry");
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(16:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({
                src: { "id": 0, "type": 30000, params: ["index.html"], "bundleName": "com.example.helloworld", "moduleName": "entry" },
                controller: this.webviewController,
                renderMode: RenderMode.SYNC_RENDER // 设置为同步渲染模式
            });
            Web.debugLine("entry/src/main/ets/pages/Index.ets(17:13)", "entry");
            Web.layoutMode(WebLayoutMode.FIT_CONTENT);
            Web.overScrollMode(OverScrollMode.NEVER);
        }, Web);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("评论区");
            Text.debugLine("entry/src/main/ets/pages/Index.ets(24:13)", "entry");
            Text.fontSize(28);
            Text.fontColor("#FF0F0F");
            Text.height(100);
            Text.width("100%");
            Text.backgroundColor("#f89f0f");
        }, Text);
        Text.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
        Navigation.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "WebHeightPage";
    }
}
registerNamedRoute(() => new WebHeightPage(undefined, {}), "", { bundleName: "com.example.helloworld", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
