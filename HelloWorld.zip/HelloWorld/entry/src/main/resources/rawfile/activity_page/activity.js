const eventBus = new EventTarget();
let data = {}
function emit(eventType, detail) {
    const event = new CustomEvent(eventType, { detail });
    eventBus.dispatchEvent(event);
}

function on(eventType, listener) {
    eventBus.addEventListener(eventType, listener);
}

document.addEventListener('DOMContentLoaded', function() {
    on('activitySignup', openSignupPage);
});

function receiveActivityData(actData) {
    const activityList = document.getElementById('activity-list');
    activityList.innerHTML = '';
    // linkObj.Alert(actData[0].actName)
    data = actData
    // linkObj.Alert(data[0].actName)

    if (actData.length === 0) {
        activityList.innerHTML = '<p>暂无近期活动</p>';
        return;
    }

    actData.forEach((activity,index) => {
        const activityCard = document.createElement('div');
        activityCard.className = 'activity-card';
        activityCard.innerHTML = `
                    <h3>${activity.actName}</h3>
                    <p><strong>时间：</strong>${activity.openHour}</p>
                    <p><strong>地点：</strong>${activity.location}</p>
                    <p>${activity.desc}</p>
                    <p><strong>电话：</strong>${activity.tele}</p>
                    <button data-index="${index}">报名</button>
                `;
        activityList.appendChild(activityCard);
        // 绑定点击事件，但不直接处理，而是通过事件总线通知
        activityCard.querySelector('button').addEventListener('click', () => {
            emit('activitySignup', { index });
        });
    });
}

function openSignupPage(e) {
    const {index} = e.detail;
    if(data){
        const activityName = data[index].actName
        linkObj.navigateToWebPage("signup",activityName)
    }else{
        linkObj.Alert('暂无该活动数据')
    }
}