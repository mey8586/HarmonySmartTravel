
function receiveActivityData(actData) {
    const activityList = document.getElementById('activity-list');
    activityList.innerHTML = '';
    // linkObj.Alert(actData[0].actName)
    // linkObj.Alert(JSON.stringify(actData))

    if (actData.length === 0) {
        activityList.innerHTML = '<p>暂无近期活动</p>';
        return;
    }

    actData.forEach(activity => {
        const activityCard = document.createElement('div');
        activityCard.className = 'activity-card';
        activityCard.innerHTML = `
                    <h3>${activity.actName}</h3>
                    <p><strong>时间：</strong>${activity.openHour}</p>
                    <p><strong>地点：</strong>${activity.location}</p>
                    <p><strong>电话：</strong>${activity.tele}</p>
                `;
        activityList.appendChild(activityCard);
    });
}
// 调用鸿蒙方法打开官网
function openOfficialWebsite() {
    linkObj.navigateToWebPage("official")
}

function openActivityWebsite() {
    linkObj.navigateToWebPage("activity")
}