function submit(activityName) {
    const formData = {
        activityName,
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('email').value,
        participants: document.getElementById('participants').value
    };
    if(!formData.name||!formData.phone||!formData.email||!formData.participants){
        linkObj.refuseRegistration();
        return
    }
    // 调用鸿蒙原生方法
    linkObj.submitRegistration(formData);
}